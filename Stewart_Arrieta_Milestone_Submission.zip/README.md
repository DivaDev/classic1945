# classic1945
A bullet-storm style game designed with the game 1945 in mind for CS 5410 at Utah State University

We have the menu system,
We do have a place for high score,
reconfig controls
Gameplay (which includes movement of player, enemies blow up, keep track of score and health, and pause),
Animation,
Collision detection,
we have sound and music,

So from the requirements we have:
Gameplay, Menuing, Reconfig Controls, Particle Effects,
Server Based High score,
Animation,
Sounds & Music,
Collision,
and OTT Weapon,
Tile Rendering (must we are thinking of replacing this with enemy AI)
